'use client'

import { useState, useCallback, useMemo } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, FileUp, Send, Menu, X, CheckCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { enviarDenuncia } from '@/utils/api'

const INITIAL_FORM_STATE = {
  descripcion: '',
  ubicacion: '',
  esAnonima: true,
  nombre: ''
}

export default function Home() {
  const [formValues, setFormValues] = useState(INITIAL_FORM_STATE)
  const [archivos, setArchivos] = useState([])
  const [enviando, setEnviando] = useState(false)
  const [mensaje, setMensaje] = useState(null)
  const [menuAbierto, setMenuAbierto] = useState(false)

  const handleChange = useCallback((event) => {
    const { name, value, type, checked } = event.target
    setFormValues(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }))
  }, [])

  const handleFileChange = useCallback((event) => {
    setArchivos(Array.from(event.target.files))
  }, [])

  const resetForm = useCallback(() => {
    setFormValues(INITIAL_FORM_STATE)
    setArchivos([])
  }, [])

  const handleSubmit = async (event) => {
    event.preventDefault()
    setEnviando(true)
    setMensaje(null)

    const formData = new FormData()
    Object.entries(formValues).forEach(([key, value]) => {
      formData.append(key, value)
    })
    archivos.forEach((archivo, index) => {
      formData.append(`archivo-${index}`, archivo)
    })

    try {
      await enviarDenuncia(formData)
      setMensaje({ tipo: 'exito', texto: 'Denuncia enviada con éxito. Gracias por su colaboración.' })
      resetForm()
    } catch (error) {
      setMensaje({ tipo: 'error', texto: 'Hubo un error al enviar la denuncia. Por favor, inténtelo de nuevo.' })
    } finally {
      setEnviando(false)
    }
  }

  const toggleMenu = useCallback(() => {
    setMenuAbierto(prev => !prev)
  }, [])

  const isFormValid = useMemo(() => {
    return formValues.descripcion.trim() !== '' && (formValues.esAnonima || formValues.nombre.trim() !== '')
  }, [formValues])

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-900">Sistema de Denuncias</h1>
          <button
            onClick={toggleMenu}
            className="sm:hidden p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500"
            aria-expanded={menuAbierto}
            aria-label="Abrir menú"
          >
            <Menu className="h-6 w-6" aria-hidden="true" />
          </button>
          <nav className={`${menuAbierto ? 'block' : 'hidden'} sm:block`}>
            <ul className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-4">
              <li><a href="#" className="text-gray-500 hover:text-gray-900">Inicio</a></li>
              <li><a href="#" className="text-gray-500 hover:text-gray-900">Acerca de</a></li>
              <li><a href="#" className="text-gray-500 hover:text-gray-900">Contacto</a></li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-2xl mx-auto bg-white shadow-sm rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-6">Formulario de Denuncia</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="descripcion">Descripción de la denuncia</Label>
              <Textarea
                id="descripcion"
                name="descripcion"
                value={formValues.descripcion}
                onChange={handleChange}
                required
                placeholder="Describa los hechos de manera clara y concisa..."
                className="mt-1 min-h-[150px]"
              />
            </div>
            <div>
              <Label htmlFor="ubicacion">Ubicación (opcional)</Label>
              <Input
                type="text"
                id="ubicacion"
                name="ubicacion"
                value={formValues.ubicacion}
                onChange={handleChange}
                placeholder="Ej: Calle, Barrio, Ciudad..."
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="archivos">Adjuntar archivos (opcional)</Label>
              <Input
                type="file"
                id="archivos"
                multiple
                onChange={handleFileChange}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => document.getElementById('archivos').click()}
                className="w-full mt-1"
              >
                <FileUp className="mr-2 h-4 w-4" /> Seleccionar archivos
              </Button>
              {archivos.length > 0 && (
                <p className="mt-2 text-sm text-gray-500">{archivos.length} archivo(s) seleccionado(s)</p>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="anonima"
                name="esAnonima"
                checked={formValues.esAnonima}
                onCheckedChange={(checked) => setFormValues(prev => ({ ...prev, esAnonima: checked }))}
              />
              <Label htmlFor="anonima">Denuncia anónima</Label>
            </div>
            {!formValues.esAnonima && (
              <div>
                <Label htmlFor="nombre">Nombre</Label>
                <Input
                  type="text"
                  id="nombre"
                  name="nombre"
                  value={formValues.nombre}
                  onChange={handleChange}
                  placeholder="Su nombre"
                  className="mt-1"
                  required
                />
              </div>
            )}
            <Button type="submit" disabled={enviando || !isFormValid} className="w-full">
              {enviando ? 'Enviando...' : 'Enviar denuncia'}
              <Send className="ml-2 h-4 w-4" />
            </Button>
          </form>
          {mensaje && (
            <Alert className={`mt-6 ${mensaje.tipo === 'exito' ? 'bg-green-100' : 'bg-red-100'}`}>
              {mensaje.tipo === 'exito' ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
              <AlertTitle>{mensaje.tipo === 'exito' ? 'Éxito' : 'Error'}</AlertTitle>
              <AlertDescription>{mensaje.texto}</AlertDescription>
            </Alert>
          )}
        </div>
      </main>

      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <p className="text-sm">&copy; 2024 Sistema de Denuncias. Todos los derechos reservados.</p>
            <nav className="mt-4 sm:mt-0">
              <ul className="flex space-x-4">
                <li><a href="#" className="hover:text-gray-300">Términos de uso</a></li>
                <li><a href="#" className="hover:text-gray-300">Política de privacidad</a></li>
              </ul>
            </nav>
          </div>
        </div>
      </footer>
    </div>
  )
}