import { useState } from 'react';
import { FileUp, X } from 'lucide-react';
import { Button } from "@/components/ui/button";

export function CargaArchivos({ onFileChange }) {
  const [archivos, setArchivos] = useState([]);

  const handleFileChange = (event) => {
    const nuevosArchivos = Array.from(event.target.files);
    setArchivos(prev => [...prev, ...nuevosArchivos]);
    onFileChange([...archivos, ...nuevosArchivos]);
  };

  const eliminarArchivo = (index) => {
    const nuevosArchivos = archivos.filter((_, i) => i !== index);
    setArchivos(nuevosArchivos);
    onFileChange(nuevosArchivos);
  };

  return (
    <div>
      <input
        type="file"
        id="archivos"
        multiple
        onChange={handleFileChange}
        className="hidden"
      />
      <Button
        type="button"
        variant="outline"
        onClick={() => document.getElementById('archivos').click()}
        className="w-full mt-1"
      >
        <FileUp className="mr-2 h-4 w-4" /> Seleccionar archivos
      </Button>
      {archivos.length > 0 && (
        <ul className="mt-2 space-y-2">
          {archivos.map((archivo, index) => (
            <li key={index} className="flex items-center justify-between text-sm text-gray-600">
              <span>{archivo.name}</span>
              <button onClick={() => eliminarArchivo(index)} className="text-red-500">
                <X className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}