'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { AlertCircle, FileUp, Send } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { enviarDenuncia } from '@/utilidades/api'
import { useFormulario } from '@/hooks/useFormulario'
import { CargaArchivos } from '@/componentes/CargaArchivos'
import { Notificacion } from '@/componentes/Notificacion'
import { loadReCaptcha, ReCaptcha } from 'react-recaptcha-v3'
import { obtenerIP, obtenerUbicacion } from '@/utilidades/geolocalizacion'

export default function FormularioDenuncia() {
  const [archivos, setArchivos] = useState([])
  const [enviando, setEnviando] = useState(false)
  const [mensaje, setMensaje] = useState(null)
  const [errores, setErrores] = useState({})

  const [formValues, handleChange, setFormValues] = useFormulario({
    descripcion: '',
    ubicacion: '',
    esAnonima: true,
    nombre: ''
  })

  useEffect(() => {
    loadReCaptcha('TU_CLAVE_DEL_SITIO_RECAPTCHA')
  }, [])

  const validarFormulario = (valores) => {
    const nuevosErrores = {}
    if (!valores.descripcion.trim()) {
      nuevosErrores.descripcion = 'La descripción es obligatoria'
    }
    if (!valores.esAnonima && !valores.nombre.trim()) {
      nuevosErrores.nombre = 'El nombre es obligatorio si la denuncia no es anónima'
    }
    return nuevosErrores
  }

  const manejarEnvio = async (event) => {
    event.preventDefault()
    setEnviando(true)
    setMensaje(null)

    const nuevosErrores = validarFormulario(formValues)
    setErrores(nuevosErrores)

    if (Object.keys(nuevosErrores).length === 0) {
      const formData = new FormData(event.currentTarget)
      formData.append('esAnonima', formValues.esAnonima.toString())
      archivos.forEach((archivo, index) => {
        formData.append(`archivo-${index}`, archivo)
      })

      try {
        const token = await ReCaptcha.execute('accion_denuncia')
        formData.append('recaptcha_token', token)

        const ip = await obtenerIP()
        formData.append('ip_anonima', ip)

        const ubicacion = await obtenerUbicacion()
        formData.append('ubicacion_aproximada', JSON.stringify(ubicacion))

        await enviarDenuncia(formData)
        setMensaje({ tipo: 'exito', texto: 'Denuncia enviada con éxito. Gracias por su colaboración.' })
        event.currentTarget.reset()
        setArchivos([])
        setFormValues({
          descripcion: '',
          ubicacion: '',
          esAnonima: true,
          nombre: ''
        })
      } catch (error) {
        console.error('Error al enviar denuncia:', error)
        setMensaje({ tipo: 'error', texto: 'Hubo un error al enviar la denuncia. Por favor, inténtelo de nuevo.' })
      } finally {
        setEnviando(false)
      }
    } else {
      setEnviando(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto bg-white shadow-sm rounded-lg p-6">
      <h2 className="text-xl font-semibold mb-6">Formulario de Denuncia</h2>
      <form onSubmit={manejarEnvio} className="space-y-6">
        <div>
          <Label htmlFor="descripcion">Descripción de la denuncia</Label>
          <Textarea
            id="descripcion"
            name="descripcion"
            value={formValues.descripcion}
            onChange={handleChange}
            required
            placeholder="Describa los hechos de manera clara y concisa..."
            className="mt-1 min-h-[150px]"
          />
          {errores.descripcion && <p className="text-red-500 text-sm mt-1">{errores.descripcion}</p>}
        </div>
        <div>
          <Label htmlFor="ubicacion">Ubicación (opcional)</Label>
          <Input
            type="text"
            id="ubicacion"
            name="ubicacion"
            value={formValues.ubicacion}
            onChange={handleChange}
            placeholder="Ej: Calle, Barrio, Ciudad..."
            className="mt-1"
          />
        </div>
        <CargaArchivos onFileChange={setArchivos} />
        <div className="flex items-center space-x-2">
          <Switch
            id="anonima"
            name="esAnonima"
            checked={formValues.esAnonima}
            onCheckedChange={(checked) => setFormValues(prev => ({ ...prev, esAnonima: checked }))}
          />
          <Label htmlFor="anonima">Denuncia anónima</Label>
        </div>
        {!formValues.esAnonima && (
          <div>
            <Label htmlFor="nombre">Nombre (opcional)</Label>
            <Input
              type="text"
              id="nombre"
              name="nombre"
              value={formValues.nombre}
              onChange={handleChange}
              placeholder="Su nombre"
              className="mt-1"
            />
            {errores.nombre && <p className="text-red-500 text-sm mt-1">{errores.nombre}</p>}
          </div>
        )}
        <Button type="submit" disabled={enviando} className="w-full">
          {enviando ? 'Enviando...' : 'Enviar denuncia'}
          <Send className="ml-2 h-4 w-4" />
        </Button>
      </form>
      {mensaje && <Notificacion mensaje={mensaje.texto} tipo={mensaje.tipo} />}
    </div>
  )
}