import { useState, useEffect } from 'react';
import { AlertCircle, CheckCircle, X } from 'lucide-react';

export function Notificacion({ mensaje, tipo, duracion = 5000 }) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), duracion);
    return () => clearTimeout(timer);
  }, [duracion]);

  if (!visible) return null;

  return (
    <div className={`fixed bottom-4 right-4 p-4 rounded-md shadow-lg ${
      tipo === 'exito' ? 'bg-green-500' : 'bg-red-500'
    } text-white flex items-center`}>
      {tipo === 'exito' ? <CheckCircle className="mr-2" /> : <AlertCircle className="mr-2" />}
      <span>{mensaje}</span>
      <button onClick={() => setVisible(false)} className="ml-4">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}