export default function PieDePagina() {
    return (
      <footer className="bg-gray-800 text-white py-6">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <p className="text-sm">&copy; 2024 Sistema de Denuncias. Todos los derechos reservados.</p>
            <nav className="mt-4 sm:mt-0">
              <ul className="flex space-x-4">
                <li><a href="#" className="hover:text-gray-300">Términos de uso</a></li>
                <li><a href="#" className="hover:text-gray-300">Política de privacidad</a></li>
              </ul>
            </nav>
          </div>
        </div>
      </footer>
    )
  }