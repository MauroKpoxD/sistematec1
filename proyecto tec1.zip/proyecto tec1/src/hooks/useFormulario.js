import { useState } from 'react';

export function useFormulario(valoresIniciales) {
  const [valores, setValores] = useState(valoresIniciales);

  const handleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setValores(prevValores => ({
      ...prevValores,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  return [valores, handleChange, setValores];
}