export async function obtenerIP() {
    const respuesta = await fetch('https://api.ipify.org?format=json');
    const data = await respuesta.json();
    return data.ip;
  }
  
  export async function obtenerUbicacion() {
    const respuesta = await fetch('https://get.geojs.io/v1/ip/geo.json');
    const data = await respuesta.json();
    return {
      pais: data.country,
      region: data.region,
      ciudad: data.city
    };
  }