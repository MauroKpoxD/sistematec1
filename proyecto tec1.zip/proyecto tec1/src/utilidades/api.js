export async function enviarDenuncia(formData) {
    const respuesta = await fetch('/api/denuncias', {
      method: 'POST',
      body: formData,
    });
  
    if (!respuesta.ok) {
      const error = await respuesta.json();
      throw new Error(error.mensaje || 'Error al enviar la denuncia');
    }
  
    return await respuesta.json();
  }